# cordova-geolocalizacao
Project to use geolocation system

1. cordova create Geolocalizacao

2. Adiciomar os arquivos referente ao projeto (diretório www)

3. cd Geolocalizacao

4. cordova platform add browser

   cordova platform add android
   
   cordova plugin add cordova-plugin-geolocation

5. cordova run browser

Documentação:
https://cordova.apache.org/docs/en/10.x/reference/cordova-plugin-geolocation/index.html
